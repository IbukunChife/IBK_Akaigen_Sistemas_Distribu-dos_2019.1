import rpyc
from rpyc.utils.server import ThreadedServer
import datetime

date_time = datetime.datetime.now()
CampoDetexto = []
Usuário = []
Referencias= set()
class ChatService(rpyc.Service):
 
  def on_connect(self,conn):
    print("\nConnectado à {}".format(date_time))
    self.fn = None
  
  def on_disconnect(self,conn):
    print("Desconnectado à {}\n".format(date_time))
    
    
  def exposed_serverPrint(self,message):
    global CampoDetexto
    Usuário.append(message)
    
    for i in Referencias:
      if i is not self.fn:
        
        i(message +" Entrou no Conversa")
      

  def exposed_serverExit(self,name):
    global CampoDetexto
    Referencias.remove(self.fn)
    Usuário.remove(name)
  
  def exposed_serverPrintMessage(self,message):
    global CampoDetexto
    CampoDetexto.append(message)
    
                  
  def exposed_replyWith(self,number):
    return CampoDetexto[number]
  def exposed_replyLength(self,length):
    return len(CampoDetexto)

  def exposed_resposta(self,fn):
    self.fn = fn  # Saves the remote function for calling later
    global Referencias
    Referencias.add(fn)
	
  
    
if __name__ == "__main__":
  server = ThreadedServer(ChatService, port=18861)
  server.start()
  