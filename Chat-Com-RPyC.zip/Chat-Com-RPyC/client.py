import rpyc
from threading import Thread
import time
import sys

Capacidade=0
net=None
input_var=None
user_name=None

def myprint(message):
	print(message)

def checkAndPrint(delay,dont):
        global Capacidade
        global net
        global user_name
        global input_var
        while(1==1):
                Tamanho=conn.root.replyLength(1)
                if (input_var=="exit"):      
                        break
                while(Capacidade<Tamanho):
                        net=conn.root.replyWith(Capacidade)
                        Capacidade=Capacidade+1
                        print (net)
        
conn = rpyc.connect('localhost',18861)
conn.root.resposta(myprint)

user_name = input("Digite seu nome de Usuário: ")
print("Digite exit para sair da Conversa")
conn.root.serverPrint(user_name)
reach = conn.root.replyLength(1)

try:
       t= Thread(target=checkAndPrint,args=(0,0))
       t.start()
       
       while(1):
               
                input_var = input()
                if(input_var=="exit"):
                        time.sleep(1)
                        input_var = user_name + " has left the conversation" 
                        conn.root.resposta(myprint)
                        conn.root.serverPrintMessage(input_var)
                        conn.root.serverExit(user_name)
                        break
                Capacidade=Capacidade+1
                input_var = user_name + ":" + input_var 
                conn.root.resposta(myprint)
                conn.root.serverPrintMessage(input_var)
        	
except  Exception as errtxt :
        print ("Você saiu do Chat")



        
