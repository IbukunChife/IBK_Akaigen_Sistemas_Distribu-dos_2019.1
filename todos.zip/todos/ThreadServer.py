#!/usr/bin/env python

from argparse import ArgumentParser
from threading import Lock, Thread
from socket import SO_REUSEADDR, SOCK_STREAM, socket, SOL_SOCKET, AF_INET
import time
import logging
import threading

logging.basicConfig(filename = 'MultiServer.log', level = logging.INFO, format = '%(asctime)s:%(message)s')

#Clear Previous File Log
with open('MultiServer.log', 'w'):
    pass

#---------------------------------------#
########## USER INPUT HANDLING ##########
#---------------------------------------#

# Initialize instance of an argument parser
parser = ArgumentParser(description='Multi-threaded TCP Server')

# Add optional argument, with given default values if user gives no arg
parser.add_argument('-p', '--port', default=9000, type=int, help='Port over which to connect.')
parser.add_argument('-t', '--secs', default=60, type=int, help='How Long should the server be receiving requests.')

# Get the arguments
args = parser.parse_args()

# -------------------------------------------#
########## DEFINE GLOBAL VARIABLES ##########
#-------------------------------------------#

req_count = 0
response_message = "Now serving, number: "
thread_lock = Lock()
max_active_threads = 0

# Create a server TCP socket and allow address re-use
s = socket(AF_INET, SOCK_STREAM)
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(('127.0.0.1', args.port))

# Create a list in which threads will be stored in order to be joined later
threads = []

#---------------------------------------------------------#
########## THREADED CLIENT HANDLER CONSTRUCTION ###########
#---------------------------------------------------------#

def countdown(n):
    while n > 0:
        n-=1
        print("                             Server will stop listening in " + str(n) + " seconds.", end="\r")
        time.sleep(1)
    print("\nServer has stopped listening.")


class ClientHandler(Thread):
    def __init__(self, address, port, socket, response_message, lock):
        Thread.__init__(self)
        self.address = address
        self.port = port
        self.socket = socket
        self.response_message = response_message
        self.lock = lock

    # Define the actions the thread will execute when called.
    def run(self):
        global req_count
        global max_active_threads
        time_start = time.time()
        t_alive = threading.active_count()
        t_name = self.ident
        if t_alive > max_active_threads:
            max_active_threads = t_alive
        self.socket.send(bytes(self.response_message + str(req_count), 'utf-8'))
        time_end = time.time()
        time_exec = time_end - time_start
        # Lock the changing of the shared req_count value to prevent erratic multithread changing behavior
        with self.lock:
            req_count += 1
            response_log = f"Active Threads: {t_alive}   |   Current_Thread: {t_name}  |   Request Replied Number: {req_count}     |   Execution Time: {time_exec}"
            logging.info(response_log)
            print("Requests Replied:" + str(req_count), end="\r")
        self.socket.close()

#-----------------------------------------------#
########## MAIN-THREAD SERVER INSTANCE ##########
#-----------------------------------------------#

input("Press Enter to Start Listening...")

# Continuously listen for a client request and spawn a new thread to handle every request
print("Server is now listening...")

start = time.time()
timer_thread = Thread(target=countdown, args=(args.secs,))
timer_thread.start()

while 1:
    try:
        # Listen for a request
        s.listen(1)
        # Accept the request
        sock, addr = s.accept()
        # Spawn a new thread for the given request
        newThread = ClientHandler(addr[0], addr[1], sock, response_message, thread_lock)
        newThread.start()
        threads.append(newThread)
        end = time.time()
        exec_time = end - start
    except KeyboardInterrupt:
        print("\nExiting Server\n")
        break
    if args.secs > 0:
        if exec_time >= args.secs:       
            break
    time.sleep(0.5)        
    req_per_sec = req_count/args.secs
    text1 = (f'Total requests replied: {req_count}     |   Requests replied per second: {req_per_sec}')
    text2 = (f'Number of threads created: {len(threads)}     |   Maximum active threads: {max_active_threads}')
    logging.info(text1)
    logging.info(text2)
    print (text1)
    print (text2)



# When server ends gracefully (through user keyboard interrupt), wait until remaining threads finish
for item in threads:
    item.join()
timer_thread.join()
