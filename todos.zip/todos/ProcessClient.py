import socket
# Rodar com Python  3.7
if __name__ == "__main__":
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("127.0.0.1", 9000))
    data = "Some Data cliente ONE For Servers"
    count = 0
    while count<100000:
        sock.sendall(data.encode('utf-8')) #send for the server
        result = sock.recv(1024)
        print (str(result)+":"+str(count))
        count += 1
#sock.close()
