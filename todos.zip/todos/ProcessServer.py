import multiprocessing
import socket
import time
from datetime import datetime

CountPros = 0
counter = 0

#Clear Previous File Log
open("Avaliacao_SMulti_Process.txt","w").close

def handle(connection, address):
    import logging
    global CountPros
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("process-%r" % (address,))
    try:
        logger.debug("Connected %r at %r", connection, address)
        counter = 0
        date_inicio = datetime.now()
        inicio = time.time()
        while True:
            data = connection.recv(1024)
            if data == "":
                logger.debug("Socket closed remotely")
                break
            logger.debug("Received data %r", data)
            connection.sendall(str.encode("Resposta do servidor Master"))
            logger.debug("Sent data")
        counter +=1
    except:
        logger.exception("Problem handling request")
    finally:
        logger.debug("Closing socket")
    fim = time.time()
    date_fim = datetime.now()
    executed_ = fim - inicio
    results ="Process "+str(CountPros)+"\nDate Inicial: "+str(date_inicio)+"\nDate final: "+str(date_fim)+"\nExec time: "+str(executed_)+" Request replied number "+str(counter)
    try:
        arq = open("Avaliacao_SMulti_Process.txt","a")   
        arq.write(results)
        arq.write("\n\n")
        arq.close()                
        print('\nRegistro gravado com sucesso')
    except IOError:
        print('\nErro ao abrir o arquivo!') 
    connection.close()

class Server(object):
    def __init__(self, hostname, port):
        import logging
        self.logger = logging.getLogger("server")
        self.hostname = hostname
        self.port = port

    def start(self):
        self.logger.debug("listening")
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind((self.hostname, self.port))
        self.socket.listen(1)
        global CountPros
        while True:
            conn, address = self.socket.accept()
            self.logger.debug("Got connection")
            process = multiprocessing.Process(target=handle, args=(conn, address))
            process.daemon = True
            process.start()
            CountPros += 1	#Adicionei um contador do Numero de Processo
            self.logger.debug("Started process %r", process)

if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    server = Server("127.0.0.1", 9000)
    try:
        logging.info("Listening")
        server.start()
    except:
        logging.exception("Unexpected exception")
    finally:
        logging.info("Shutting down")
        for process in multiprocessing.active_children():
            logging.info("Shutting down process %r", process)
            process.terminate()
            process.join()
    logging.info("All done")
