import socket

if __name__ == "__main__":
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("localhost", 9000))
    data = "Some Data cliente For Servers"
    count = 0
    while True:
	sock.sendall(data) #send for the server
	result = sock.recv(1024)
    	print result
	count += 1
#sock.close()
