import socket
# Rodar com Python  3.7
if __name__ == "__main__":
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("172.22.13.121", 9000))
    data = "Some Data cliente TWO For Servers"
    count = 0
    while count<2000000:
        sock.sendall(data.encode('utf-8')) #send for the server
        result = sock.recv(1024)
        print (str(result)+":"+str(count))
        count += 1
#sock.close()
