import socket
# RODAR NA COM O PYTHON 2.7
if __name__ == "__main__":
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(("172.22.13.121", 9000))
    data = "Some Data of client TBA1 For Servers"
    count = 0
    while count < 1000000:
    	sock.sendall(data) #send for the server
    	result = sock.recv(1024)
    	print (result + " Msg " + str(count))
    	count += 1
#sock.close()
