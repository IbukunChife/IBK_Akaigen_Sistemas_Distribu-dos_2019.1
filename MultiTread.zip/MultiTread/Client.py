#!/usr/bin/env python
from queue import Queue
from argparse import ArgumentParser
from socket import SO_REUSEADDR, SOCK_STREAM, error, socket, SOL_SOCKET, AF_INET
from threading import Thread
import time
import os
# -------------------------------------#
########## ARGUMENT HANDLING ##########
#-------------------------------------#

# Initialize instance of an argument parser
parser = ArgumentParser(description='Multi-threaded TCP Client')

# Add optional arguments, with given default values if user gives no args
parser.add_argument('-r', '--requests', default=5000, type=int, help='Total number of requests to send to server')
parser.add_argument('-w', '--workerThreads', default=10, type=int, help='Max number of worker threads to be created')
parser.add_argument('-i', '--ip', default='127.0.0.1', help='IP address to connect over')
parser.add_argument('-p', '--port', default=9000, type=int, help='Port over which to connect')
parser.add_argument('-t', '--timer', default=9999, type=int, help='Execution Time')

# Get the arguments
args = parser.parse_args()

#--------------------------------------#
########## CLIENT CONSTRUCTOR ##########
#--------------------------------------#


class Client:
    def __init__(self, id, address, port, message):
        self.s = socket(AF_INET, SOCK_STREAM)
        self.id = id
        self.address = address
        self.port = port
        self.message = str(message)

    def run(self):
        try:
            # Timeout if the no connection can be made in 5 seconds
            self.s.settimeout(10)
            # Allow socket address reuse
            self.s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
            # Connect to the ip over the given port
            self.s.connect((self.address, self.port))
            # Send the defined request message
            self.s.send(bytes(self.message, 'utf-8'))
            # Wait to receive data back from server
            data = self.s.recv(1024)
            # Notify that data has been received
            print(self.id, ":  received: ", data)
            # CLOSE THE SOCKET
            self.s.close()
        # If something went wrong, notify the user
        except error as e:
            print("\nERROR: Could not connect to ", self.address, " over port", self.port, "\n")
            #raise e

#------------------------------------------------#
########## DEFINE QUEUE WORKER FUNCTION ##########
#------------------------------------------------#

# Create a queue to hold the tasks for the worker threads
q = Queue(maxsize=0)


# Function which generates a Client instance, getting the work item to be processed from the queue
def worker(i):
    message = "HELLO"
    print(i)
    while not q.empty():
        # Get the task from teh work queue
        item = q.get()

        new_client = Client(item, args.ip, args.port, message)
        new_client.run()
        # Mark this task item done, thus removing it from the work queue
        q.task_done()
        print("Thread "+str(i)+" Executing")
        end = time.time()
        executed_ = end - start
        print("Exec time: "+str(executed_))
        if args.timer > 0:
            if executed_ >= args.timer:
                print("Timer finished.")
                os._exit(0)
    return True

#--------------------------------------------------#
########## INITIATE CLIENT WORKER THREADS ##########
#--------------------------------------------------#
start = time.time()
# Populate the work queue with a list of numbers as long as the total number of requests wished to be sent.
# These queue items can be thought of as decrementing counters for the client thread workers.
for item in range(args.requests):
    q.put(item)

# Create a number of threads, given by the maxWorkerThread variable, to initiate clients and begin sending requests.
print(args.workerThreads)
jobs = []
for i in range(0,args.workerThreads):
    t = Thread(target=worker,args=(i,)) #t = Thread(target=worker(i))
    print("Thread "+str(i)+" Started")
    t.setDaemon(True)    #setting threads as "daemon" allows main program to 
                         #exit eventually even if these dont finish 
                         #correctly.
    jobs.append(t)

# Start the threads (i.e. calculate the random number lists)
for j in jobs:
    j.start()

# Ensure all of the threads have finished
for j in jobs:
    j.join()
    
# Do not exit the main thread until the sub-threads complete their work queue
q.join()

