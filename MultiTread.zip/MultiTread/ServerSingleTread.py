# import socket programming library 
import socket 

# import thread module 
from _thread import *
import threading 

import time
from datetime import datetime

print_lock = threading.Lock()
count_cli = 0
count = 0

#Clear Previous File Log
open("Avaliacao_SSingle_Thread.txt","w").close

# thread fuction 
def threaded(c,addr): 
	import logging
	global count, count_cli
	logging.basicConfig(level=logging.DEBUG)
	logger = logging.getLogger("Client-%r" % (addr))
	try:
		logger.debug("Connected %r at %r", c, addr)

		count = 0
		count_cli += 1

		date_inicio = datetime.now()
		inicio = time.time()
		while True: 

			# data received from client 
			data = c.recv(1024) 
			if not data:  
				
				# lock released on exit 
				logger.debug("Socket closed remotely")
				print_lock.release() 
				break

			# reverse the given string from client 
			logger.debug("Received data %r", data)
			data = data[::-1] 

			# send back reversed string to client 
			logger.debug("Sent data")
			c.send(data) 
			count += 1
	except:
		logger.exception("Problem handling request")
	finally:
		logger.debug("Closing socket")

	fim = time.time()
	date_fim = datetime.now()
	executed_ = fim - inicio
	results = []
	results.append("\nClient "+str(count_cli)+"	Address "+str(addr))
	results.append("\nDate Inicial:	"+str(date_inicio)+"\nDate final:	"+str(date_fim))
	results.append("\nExec time:	"+str(executed_)+" s\nRequest replied number: "+str(count))
	try:
		arq = open("Avaliacao_SSingle_Thread.txt","a")   
		arq.write("".join(results))
		arq.write("\n\n")
		arq.close()
		print('\nRegistro gravado com sucesso')
	except IOError:
		print('\nErro ao abrir o arquivo!') 
	# connection closed 
	c.close()


def Main(): 
	host = "172.22.13.133" 
	port = 9000

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
	s.bind((host, port)) 
	print("socket binded to post", port) 

	# put the socket into listening mode 
	s.listen(5) 
	print("socket is listening") 

	# a forever loop until client wants to exit 
	while True:
		# establish connection with client 
		c, addr = s.accept() 

		# lock acquired by client 
		print_lock.acquire() 
		print ("\n\nConnected to: "+str(addr[0])+" : "+str(addr[1]))

		# Start a new thread and return its identifier 
		start_new_thread(threaded, (c,addr[0],)) 
	s.close() 


if __name__ == '__main__': 
	Main() 
